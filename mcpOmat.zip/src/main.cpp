﻿// ESP32_PitterOmat_RS485.ino
// ESP32-S3 Touch LCD 4 (480x480) + LVGL + EEZ Flow + RS485 Master
// Backlight: Board-Hardware (keine explizite TCA9554-Steuerung).
// LVGL: Single-Buffer, damit keine "LVGL buffer alloc failed" Fehler auftreten.

#include <lvgl.h>
#include "Arduino_GFX_Library.h"
#include "TouchDrvGT911.hpp"
#include <Wire.h>
#include "esp_timer.h"
#include "settings_store.h"

#if defined(ARDUINO_USB_MODE) && (ARDUINO_USB_MODE == 1)
#include "HWCDC.h"
#define USBSerial HWCDCSerial
#define USE_NATIVE_USB 1
#elif defined(ARDUINO_USB_MODE) && (ARDUINO_USB_MODE == 0)
#include "USB.h"
#define USE_NATIVE_USB 1
#else
#define USBSerial Serial
#define USE_NATIVE_USB 0
#endif

#if LV_USE_LOG
static void lvlog_cb(const char *s) { USBSerial.printf("%s", s); USBSerial.flush(); }
#endif

// --- EEZ / UI ---
#include "ui.h"
#include "vars.h"
#include "eez-flow.h"
#include "actions.h"

extern "C" __attribute__((weak)) void eez_flow_tick(void) {}
extern "C" __attribute__((weak)) void ui_tick(void) {}

#define LVGL_TICK_PERIOD_MS 2

#ifndef DISPLAY_ID
  #define DISPLAY_ID 1
#endif

// --- Arduino_GFX: Bus + RGB Panel + Display ---
Arduino_DataBus *bus = new Arduino_SWSPI(
  GFX_NOT_DEFINED /* DC */, 42 /* CS */,
  2 /* SCK */, 1 /* MOSI */, GFX_NOT_DEFINED /* MISO */);

Arduino_ESP32RGBPanel *rgbpanel = new Arduino_ESP32RGBPanel(
  40 /* DE */, 39 /* VSYNC */, 38 /* HSYNC */, 41 /* PCLK */,
  46 /* R0 */, 3 /* R1 */, 8 /* R2 */, 18 /* R3 */, 17 /* R4 */,
  14 /* G0 */, 13 /* G1 */, 12 /* G2 */, 11 /* G3 */, 10 /* G4 */, 9 /* G5 */,
  5 /* B0 */, 45 /* B1 */, 48 /* B2 */, 47 /* B3 */, 21 /* B4 */,
  1 /* hsync_polarity */, 10 /* hsync_front_porch */, 8 /* hsync_pulse_width */, 50 /* hsync_back_porch */,
  1 /* vsync_polarity */, 10 /* vsync_front_porch */, 8 /* vsync_pulse_width */, 20 /* vsync_back_porch */);

Arduino_RGB_Display *gfx = new Arduino_RGB_Display(
  480, 480, rgbpanel,
  2, false,  // auto_flush AUS
  bus, GFX_NOT_DEFINED,
  st7701_type1_init_operations, sizeof(st7701_type1_init_operations));

// --- Touch GT911 ---
TouchDrvGT911 GT911;
int16_t txs[5], tys[5];

// --- LVGL Draw Buffers (Single Buffer) ---
static lv_disp_draw_buf_t draw_buf;
static lv_color_t *buf1 = nullptr;
static uint32_t screenWidth  = 0;
static uint32_t screenHeight = 0;

static bool g_previewActive = false;

static String usbIn;

static void usbPoll() {
  while (USBSerial.available()) {
    char c = (char)USBSerial.read();
    if (c == '\r' || c == '\n') {
      if (usbIn.length()) {
        if (usbIn.equalsIgnoreCase("ping")) {
          USBSerial.println("pong");
        } else if (usbIn.equalsIgnoreCase("heap")) {
          USBSerial.printf("heap=%u psram=%u\n",
              heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
              heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
        } else if (usbIn.equalsIgnoreCase("info")) {
          USBSerial.printf("IDF=%s, core freq=%uMHz\n", IDF_VER, F_CPU/1000000);
        }
      }
      usbIn = "";
    } else {
      if (usbIn.length() < 80) usbIn += c;
    }
  }
}

// --- LVGL flush ---
static void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
  uint32_t w = area->x2 - area->x1 + 1;
  uint32_t h = area->y2 - area->y1 + 1;
#if (LV_COLOR_16_SWAP != 0)
  gfx->draw16bitBeRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#else
  gfx->draw16bitRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#endif
  lv_disp_flush_ready(disp);
}

// --- LVGL tick ISR ---
static void lvgl_tick_cb(void *arg) {
  (void)arg;
  lv_tick_inc(LVGL_TICK_PERIOD_MS);
}

// --- Touch -> LVGL ---
static void my_touchpad_read(lv_indev_drv_t *indev, lv_indev_data_t *data) {
  (void)indev;
  uint8_t n = GT911.getPoint(txs, tys, GT911.getSupportTouchPoint());
  if (n > 0) {
    int16_t x = txs[0], y = tys[0];
    switch (gfx->getRotation()) {
      case 0: break;
      case 1: {
        int16_t _x = y;
        int16_t _y = gfx->height() - x;
        x = _x; y = _y;
        break;
      }
      case 2:
        x = gfx->width()  - x;
        y = gfx->height() - y;
        break;
      case 3: {
        int16_t _x = gfx->width() - y;
        int16_t _y = x;
        x = _x; y = _y;
        break;
      }
    }
    data->state   = LV_INDEV_STATE_PRESSED;
    data->point.x = x;
    data->point.y = y;
  } else {
    data->state = LV_INDEV_STATE_RELEASED;
  }
}

// === RS485 Master (MAX485) ===================================================
constexpr uint32_t RS485_BAUD = 115200;
HardwareSerial &RS485 = Serial2;
constexpr int RS485_RX_PIN = 43;
constexpr int RS485_TX_PIN = 44;
constexpr int RS485_DE_PIN = 4;

static void rs485SendLine(const char *line);

static inline void rs485SendRaw(const uint8_t *data, size_t len) {
  digitalWrite(RS485_DE_PIN, HIGH);
  delayMicroseconds(10);
  RS485.write(data, len);
  RS485.flush();
  delayMicroseconds(20);
  digitalWrite(RS485_DE_PIN, LOW);
}

static void logRs485Line(const char *prefix, const char *line, size_t len = 0) {
  if (!line) {
    return;
  }
  if (len == 0) {
    len = strlen(line);
  }
  while (len && (line[len - 1] == '\r' || line[len - 1] == '\n')) {
    --len;
  }
  USBSerial.print(prefix);
  if (len) {
    USBSerial.write(reinterpret_cast<const uint8_t *>(line), len);
  }
  USBSerial.println();
}
static void logRs485Line(const char *prefix, const String &line) {
  logRs485Line(prefix, line.c_str(), line.length());
}

static void rs485SendLine(const char *line) {
  if (!line) {
    return;
  }
  logRs485Line("[RS485-TX] ", line);
  rs485SendRaw((const uint8_t*)line, strlen(line));
}

// === RS485 RX Parser =========================================================
String rsInLine;
static void handleRs485Line(const String &line);

static void rs485Poll() {
  while (RS485.available()) {
    char c = (char)RS485.read();
    if (c == '\n') {
      if (rsInLine.length() > 0) {
        logRs485Line("[RS485-RX] ", rsInLine);
        handleRs485Line(rsInLine);
      }
      rsInLine = "";
    } else if (c != '\r') {
      rsInLine += c;
      if (rsInLine.length() > 80) {
        rsInLine = "";
      }
    }
  }
}

// === Helper fÃ¼r EEZ Globals ==================================================
static inline int32_t gv_i(unsigned idx) {
  int err = 0;
  eez::Value v = eez::flow::getGlobalVariable(idx);
  return v.toInt32(&err);
}
static inline bool gv_b(unsigned idx) {
  int err = 0;
  eez::Value v = eez::flow::getGlobalVariable(idx);
  return v.toBool(&err);
}

static inline int clampInt(int value, int minVal, int maxVal) {
  if (value < minVal) return minVal;
  if (value > maxVal) return maxVal;
  return value;
}

static PlayerStateSettings collectPlayerStateFromFlow() {
  PlayerStateSettings state;
  state.playerCount  = (uint8_t)clampInt(gv_i(FLOW_GLOBAL_VARIABLE_PLAYER_COUNT), 1, 6);
  state.mode         = (uint8_t)clampInt(gv_i(FLOW_GLOBAL_VARIABLE_PLAYER_COLOR_MODE_INDEX), 0, 5);
  state.singleColor  = (uint8_t)clampInt(gv_i(FLOW_GLOBAL_VARIABLE_PLAYER_SINGLE_COLOR_INDEX), 0, 6);
  state.ownRandom    = (uint8_t)clampInt(gv_i(FLOW_GLOBAL_VARIABLE_PLAYER_OWN_COLOR_FLAG), 0, 1);
  state.inactiveMode = (uint8_t)clampInt(gv_i(FLOW_GLOBAL_VARIABLE_INACTIVE_EFFECT_INDEX), 0, 3);
  return state;
}

static BorderStateSettings collectBorderStateFromFlow() {
  BorderStateSettings state;
  state.mode        = (uint8_t)clampInt(gv_i(FLOW_GLOBAL_VARIABLE_BORDER_COLOR_MODE_INDEX), 0, 2);
  state.singleColor = (uint8_t)clampInt(gv_i(FLOW_GLOBAL_VARIABLE_BORDER_SINGLE_COLOR_INDEX), 0, 5);
  return state;
}

static BrightnessSettings collectBrightnessFromFlow() {
  BrightnessSettings s;
  s.game   = (uint16_t)clampInt(gv_i(FLOW_GLOBAL_VARIABLE_LED_GAME_BRIGHTNESS), 1, 255);
  s.border = (uint16_t)clampInt(gv_i(FLOW_GLOBAL_VARIABLE_LED_BORDER_BRIGHTNESS), 1, 255);
  return s;
}

static SpinSettings collectSpinFromFlow() {
  SpinSettings s;
  s.accelMin10 = (int16_t)gv_i(FLOW_GLOBAL_VARIABLE_LL_ACCEL_TURNS_MIN10);
  s.accelMax10 = (int16_t)gv_i(FLOW_GLOBAL_VARIABLE_LL_ACCEL_TURNS_MAX10);
  s.decelMin10 = (int16_t)gv_i(FLOW_GLOBAL_VARIABLE_LL_DECEL_TURNS_MIN10);
  s.decelMax10 = (int16_t)gv_i(FLOW_GLOBAL_VARIABLE_LL_DECEL_TURNS_MAX10);
  s.maxMin10   = (int16_t)gv_i(FLOW_GLOBAL_VARIABLE_LL_MAX_SPEED_TURNS_MIN10);
  s.maxMax10   = (int16_t)gv_i(FLOW_GLOBAL_VARIABLE_LL_MAX_SPEED_TURNS_MAX10);
  s.stepMs     = (int16_t)gv_i(FLOW_GLOBAL_VARIABLE_LL_STEP_MS);
  return s;
}

static bool equals(const PlayerStateSettings &a, const PlayerStateSettings &b) {
  return a.playerCount == b.playerCount &&
         a.mode == b.mode &&
         a.singleColor == b.singleColor &&
         a.ownRandom == b.ownRandom &&
         a.inactiveMode == b.inactiveMode;
}

static bool equals(const BorderStateSettings &a, const BorderStateSettings &b) {
  return a.mode == b.mode && a.singleColor == b.singleColor;
}

static bool equals(const BrightnessSettings &a, const BrightnessSettings &b) {
  return a.game == b.game && a.border == b.border;
}

static bool equals(const SpinSettings &a, const SpinSettings &b) {
  return a.accelMin10 == b.accelMin10 &&
         a.accelMax10 == b.accelMax10 &&
         a.decelMin10 == b.decelMin10 &&
         a.decelMax10 == b.decelMax10 &&
         a.maxMin10   == b.maxMin10 &&
         a.maxMax10   == b.maxMax10 &&
         a.stepMs     == b.stepMs;
}

static void sendPlayerState(const PlayerStateSettings &state) {
  char buf[64];
  snprintf(buf, sizeof(buf), "PLAYER_STATE %u %u %u %u %u\n",
           state.playerCount, state.mode, state.singleColor,
           state.ownRandom, state.inactiveMode);
  rs485SendLine(buf);

  snprintf(buf, sizeof(buf), "CFG_PLAYERS %u\n", state.playerCount);
  rs485SendLine(buf);
}

static void sendBorderState(const BorderStateSettings &state) {
  char buf[48];
  snprintf(buf, sizeof(buf), "BORDER_STATE %u %u\n", state.mode, state.singleColor);
  rs485SendLine(buf);
}

static void sendBrightnessState(const BrightnessSettings &state) {
  char buf[48];
  snprintf(buf, sizeof(buf), "BRIGHT_STATE %u %u\n", state.game, state.border);
  rs485SendLine(buf);
}

static void sendSpinState(const SpinSettings &state) {
  char buf[96];
  snprintf(buf, sizeof(buf),
           "SPIN_PARAMS %d %d %d %d %d %d %d\n",
           state.accelMin10, state.accelMax10,
           state.maxMin10, state.maxMax10,
           state.decelMin10, state.decelMax10,
           state.stepMs);
  rs485SendLine(buf);
}

static void sendShowBorders(bool enable, uint8_t playerCount) {
  char buf[48];
  snprintf(buf, sizeof(buf), "BORDERS_STATE %d %u\n", enable ? 1 : 0, playerCount);
  rs485SendLine(buf);
}

static void sendBrightnessPair(const BrightnessSettings &state) {
  sendBrightnessState(state);
  char buf[48];
  snprintf(buf, sizeof(buf), "SET_BRIGHTNESS G %u\n", state.game);
  rs485SendLine(buf);
  snprintf(buf, sizeof(buf), "SET_BRIGHTNESS B %u\n", state.border);
  rs485SendLine(buf);
}

static void sendAllSettingsToArduino() {
  const PlayerStateSettings &player = settings_get_player();
  const BorderStateSettings &border = settings_get_border();
  const BrightnessSettings &bright  = settings_get_brightness();
  const SpinSettings &spin          = settings_get_spin();

  sendPlayerState(player);
  sendBorderState(border);
  sendBrightnessPair(bright);
  sendSpinState(spin);
  sendShowBorders(settings_get_show_borders(), player.playerCount);
}

static PlayerStateSettings g_cachedPlayerState{};
static BorderStateSettings g_cachedBorderState{};
static BrightnessSettings g_cachedBrightness{};
static SpinSettings g_cachedSpin{};
static bool g_cachedPlayerValid = false;
static bool g_cachedBorderValid = false;
static bool g_cachedBrightnessValid = false;
static bool g_cachedSpinValid = false;
static bool g_cachedShowBorders = false;
static bool g_cachedShowBordersValid = false;

static void updateCachedStatesFromSettings() {
  g_cachedPlayerState = settings_get_player();
  g_cachedBorderState = settings_get_border();
  g_cachedBrightness  = settings_get_brightness();
  g_cachedSpin        = settings_get_spin();
  g_cachedShowBorders = settings_get_show_borders();
  g_cachedPlayerValid = g_cachedBorderValid = g_cachedBrightnessValid = g_cachedSpinValid = g_cachedShowBordersValid = true;

static bool g_previewActive = false; // Skip real state sync while preview screens are active

}

static void syncPlayerStateFromFlow() {
  PlayerStateSettings st = collectPlayerStateFromFlow();
  settings_set_player_state(st);
  sendPlayerState(st);
  g_cachedPlayerState = st;
  g_cachedPlayerValid = true;
}

static void syncBorderStateFromFlow() {
  BorderStateSettings st = collectBorderStateFromFlow();
  settings_set_border_state(st);
  sendBorderState(st);
  g_cachedBorderState = st;
  g_cachedBorderValid = true;
}

static void syncBrightnessFromFlow() {
  BrightnessSettings st = collectBrightnessFromFlow();
  settings_set_brightness(st);
  sendBrightnessPair(st);
  g_cachedBrightness = st;
  g_cachedBrightnessValid = true;
}

static void syncSpinFromFlow() {
  SpinSettings st = collectSpinFromFlow();
  settings_set_spin(st);
  sendSpinState(st);
  g_cachedSpin = st;
  g_cachedSpinValid = true;
}

static void syncShowBordersFromFlow() {
  bool enable = gv_b(FLOW_GLOBAL_VARIABLE_LL_SHOW_BORDERS);
  settings_set_show_borders(enable);
  PlayerStateSettings st = collectPlayerStateFromFlow();
  settings_set_player_state(st);
  sendShowBorders(enable, st.playerCount);
  g_cachedPlayerState = st;
  g_cachedPlayerValid = true;
  g_cachedShowBorders = enable;
  g_cachedShowBordersValid = true;
}

static void pollFlowStateChanges() {
  PlayerStateSettings currentPlayer = collectPlayerStateFromFlow();
  if (!g_previewActive && (!g_cachedPlayerValid || !equals(currentPlayer, g_cachedPlayerState))) {
    settings_set_player_state(currentPlayer);
    sendPlayerState(currentPlayer);
    g_cachedPlayerState = currentPlayer;
    g_cachedPlayerValid = true;
  }

  BorderStateSettings currentBorder = collectBorderStateFromFlow();
  if (!g_previewActive && (!g_cachedBorderValid || !equals(currentBorder, g_cachedBorderState))) {
    settings_set_border_state(currentBorder);
    sendBorderState(currentBorder);
    g_cachedBorderState = currentBorder;
    g_cachedBorderValid = true;
  }

  BrightnessSettings currentBrightness = collectBrightnessFromFlow();
  if (!g_cachedBrightnessValid || !equals(currentBrightness, g_cachedBrightness)) {
    settings_set_brightness(currentBrightness);
    sendBrightnessPair(currentBrightness);
    g_cachedBrightness = currentBrightness;
    g_cachedBrightnessValid = true;
  }

  SpinSettings currentSpin = collectSpinFromFlow();
  if (!g_cachedSpinValid || !equals(currentSpin, g_cachedSpin)) {
    settings_set_spin(currentSpin);
    sendSpinState(currentSpin);
    g_cachedSpin = currentSpin;
    g_cachedSpinValid = true;
  }

  bool showBorders = gv_b(FLOW_GLOBAL_VARIABLE_LL_SHOW_BORDERS);
  if (!g_cachedShowBordersValid || showBorders != g_cachedShowBorders ||
      !g_cachedPlayerValid || currentPlayer.playerCount != g_cachedPlayerState.playerCount) {
    settings_set_show_borders(showBorders);
    sendShowBorders(showBorders, currentPlayer.playerCount);
    g_cachedShowBorders = showBorders;
    g_cachedShowBordersValid = true;
  }
}

// === Native Actions (RS485-Befehle) ==========================================
extern "C" void action_cmd_led_ring_test(lv_event_t *e) {
  (void)e;
  rs485SendLine("LED_TEST\n");
}

extern "C" void action_settings_load(lv_event_t *e) {
  (void)e;
  settings_apply_to_flow();
  sendAllSettingsToArduino();
  updateCachedStatesFromSettings();
}

extern "C" void action_settings_factory_reset(lv_event_t *e) {
  (void)e;
  settings_factory_reset();
  sendAllSettingsToArduino();
  updateCachedStatesFromSettings();
}

extern "C" void action_send_player_state(lv_event_t *e) {
  (void)e;
  syncPlayerStateFromFlow();
}

extern "C" void action_send_border_state(lv_event_t *e) {
  (void)e;
  syncBorderStateFromFlow();
}

extern "C" void action_settings_mark_dirty(lv_event_t *e) {
  (void)e;
  settings_schedule_flush();
}

extern "C" void action_settings_apply_to_flow(lv_event_t *e) {
  (void)e;
  settings_apply_to_flow();
}

extern "C" void action_settings_schedule_flush(lv_event_t *e) {
  (void)e;
  settings_schedule_flush();
}

extern "C" void action_settings_set__(lv_event_t *e) {
  (void)e;
  settings_schedule_flush();
}

extern "C" void action_send_all_settings_to_arduino(lv_event_t *e) {
  (void)e;
  sendAllSettingsToArduino();
  updateCachedStatesFromSettings();
}

extern "C" void action_cmd_send_cfg_joker(lv_event_t *e) {
  (void)e;
  bool enabled = gv_b(FLOW_GLOBAL_VARIABLE_JOKER_ENABLED);
  char buf[32];
  snprintf(buf, sizeof(buf), "CFG_JOKER %d\n", enabled ? 1 : 0);
  rs485SendLine(buf);
}

extern "C" void action_cmd_send_spin_start_to_arduino(lv_event_t *e) {
  (void)e;
  rs485SendLine("SPIN_START\n");
}

extern "C" void action_cmd_send_joker_start_to_arduino(lv_event_t *e) {
  g_previewActive = true;

  (void)e;
  rs485SendLine("JOKER:PREVIEW:START\n");
}

extern "C" void action_cmd_send_joker_stop_to_arduino(lv_event_t *e) {
  (void)e;
  rs485SendLine("JOKER:PREVIEW:STOP\n");
}

extern "C" void action_cmd_send_joker_preview(lv_event_t *e) {
  g_previewActive = true;

  (void)e;
  int mode     = gv_i(FLOW_GLOBAL_VARIABLE_JOKER_COLOR_INDEX);
  int colorIdx = mode;
  char buf[64];
  snprintf(buf, sizeof(buf), "JOKER_PREVIEW %d %d\n", mode, colorIdx);
  rs485SendLine(buf);
}

extern "C" void action_cmd_send_player_colors_preview(lv_event_t *e) {
  g_previewActive = true;

  (void)e;
  // Korrigiert: verwende INDEX-Variablen fÃ¼r Modus und Farbe
  int mode        = gv_i(FLOW_GLOBAL_VARIABLE_PLAYER_COLOR_MODE_INDEX);
  int singleIndex = gv_i(FLOW_GLOBAL_VARIABLE_PLAYER_SINGLE_COLOR_INDEX);
  int ownRandom   = gv_i(FLOW_GLOBAL_VARIABLE_PLAYER_OWN_COLOR_FLAG);
  int inactiveIdx = gv_i(FLOW_GLOBAL_VARIABLE_INACTIVE_EFFECT_INDEX);
  char buf[96];
  snprintf(buf, sizeof(buf), "PLAYER_PREVIEW %d %d %d %d\n",
           mode, singleIndex, ownRandom, inactiveIdx);
  rs485SendLine(buf);
}

extern "C" void action_cmd_send_border_colors_preview(lv_event_t *e) {
  g_previewActive = true;

  (void)e;
  // Korrigiert: verwende INDEX-Variablen fÃ¼r Grenzmodus und -farbe
  int mode        = gv_i(FLOW_GLOBAL_VARIABLE_BORDER_COLOR_MODE_INDEX);
  int singleIndex = gv_i(FLOW_GLOBAL_VARIABLE_BORDER_SINGLE_COLOR_INDEX);
  char buf[64];
  snprintf(buf, sizeof(buf), "BORDER_PREVIEW %d %d\n", mode, singleIndex);
  rs485SendLine(buf);
}

extern "C" void action_cmd_send_borders_state_to_arduino(lv_event_t *e) {
  (void)e;
  bool on = gv_b(FLOW_GLOBAL_VARIABLE_LL_SHOW_BORDERS);
  int  pc = gv_i(FLOW_GLOBAL_VARIABLE_PLAYER_COUNT);
  char buf[48];
  snprintf(buf, sizeof(buf), "BORDERS_STATE %d %d\n", on ? 1 : 0, pc);
  rs485SendLine(buf);
}

extern "C" void action_cmd_send_led_game_brightness(lv_event_t *e) {
  (void)e;
  int v = gv_i(FLOW_GLOBAL_VARIABLE_LED_GAME_BRIGHTNESS);
  if (v < 1) v = 1;
  if (v > 255) v = 255;
  char buf[40];
  snprintf(buf, sizeof(buf), "SET_BRIGHTNESS G %d\n", v);
  rs485SendLine(buf);
}

extern "C" void action_cmd_send_led_border_brightness(lv_event_t *e) {
  (void)e;
  int v = gv_i(FLOW_GLOBAL_VARIABLE_LED_BORDER_BRIGHTNESS);
  if (v < 1) v = 1;
  if (v > 255) v = 255;
  char buf[40];
  snprintf(buf, sizeof(buf), "SET_BRIGHTNESS B %d\n", v);
  rs485SendLine(buf);
}

// Display-Brightness-Slider: NO-OP (nicht verwendet)
extern "C" void action_cmd_set_display_brightness(lv_event_t *e) {
  (void)e;
}

// Spielende / Preview-Clear
extern "C" void action_cmd_send_game_end(lv_event_t *e) {
  (void)e;
  rs485SendLine("GAME_END\n");
}

extern "C" void action_cmd_send_preview_clear(lv_event_t *e) {
  g_previewActive = false;

  (void)e;
  rs485SendLine("PREVIEW_CLEAR\n");
}

// Spin-Parameter senden
extern "C" void action_cmd_send_spin_params_to_arduino(lv_event_t *e) {
  (void)e;
  int aMin = gv_i(FLOW_GLOBAL_VARIABLE_LL_ACCEL_TURNS_MIN10);
  int aMax = gv_i(FLOW_GLOBAL_VARIABLE_LL_ACCEL_TURNS_MAX10);
  int mMin = gv_i(FLOW_GLOBAL_VARIABLE_LL_MAX_SPEED_TURNS_MIN10);
  int mMax = gv_i(FLOW_GLOBAL_VARIABLE_LL_MAX_SPEED_TURNS_MAX10);
  int dMin = gv_i(FLOW_GLOBAL_VARIABLE_LL_DECEL_TURNS_MIN10);
  int dMax = gv_i(FLOW_GLOBAL_VARIABLE_LL_DECEL_TURNS_MAX10);
  int ms   = gv_i(FLOW_GLOBAL_VARIABLE_LL_STEP_MS);

  char buf[80];
  snprintf(buf, sizeof(buf),
           "SPIN_PARAMS %d %d %d %d %d %d %d\n",
           aMin, aMax, mMin, mMax, dMin, dMax, ms);
  rs485SendLine(buf);
}

// === LVGL / Display Init =====================================================
static void init_lvgl() {
  lv_init();
#if LV_USE_LOG
  lv_log_register_print_cb(lvlog_cb);
#endif

screenWidth  = gfx->width();
screenHeight = gfx->height();

/* statt 1/10 Frame: ~80 Zeilen */
size_t px_cnt = screenWidth * 80;  // 480 * 80 = 38.4k Pixel -> 76.8 kB
  buf1 = (lv_color_t *)heap_caps_malloc(px_cnt * sizeof(lv_color_t), MALLOC_CAP_DMA);
  if (!buf1) {
    USBSerial.println("LVGL DMA buffer alloc failed, fallback to smaller");
    px_cnt = screenWidth * 40;
    buf1 = (lv_color_t *)heap_caps_malloc(px_cnt * sizeof(lv_color_t), MALLOC_CAP_DMA);
  }
  if (!buf1) {
    while (true) { USBSerial.println("LVGL buffer alloc failed"); delay(1000); }
  }
  
lv_disp_draw_buf_init(&draw_buf, buf1, NULL, px_cnt);

static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res   = screenWidth;
  disp_drv.ver_res   = screenHeight;
  disp_drv.flush_cb  = my_disp_flush;
  disp_drv.draw_buf  = &draw_buf;
  disp_drv.full_refresh = 1;   // kompletter Frame â†’ weniger sichtbare Tearing/Jitter
  disp_drv.sw_rotate = 1;
  lv_disp_drv_register(&disp_drv);
  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type    = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  const esp_timer_create_args_t tick_args = {
    .callback = &lvgl_tick_cb,
    .arg = nullptr,
    .dispatch_method = ESP_TIMER_TASK,
    .name = "lvgl_tick"
  };
  esp_timer_handle_t tick = nullptr;
  esp_timer_create(&tick_args, &tick);
  esp_timer_start_periodic(tick, LVGL_TICK_PERIOD_MS * 1000);
}

// === RS485 RX Line Handler ===================================================
static void handleRs485Line(const String &line) {
  // HIT n -> Ende des Spins + Trigger
  if (line.startsWith("HIT ")) {
    int grp = atoi(line.c_str() + 4);
    if (grp < 1) grp = 1;
    if (grp > 36) grp = 36;

    
    // Joker-Hit erkennen: grp==2 bei 5 Spielern ist Joker-Spot
    {
      int errJ = 0;
      int jokerEn = eez::flow::getGlobalVariable(FLOW_GLOBAL_VARIABLE_JOKER_ENABLED).toInt32(&errJ);
      if (grp == 2) {
        eez::flow::setGlobalVariable(FLOW_GLOBAL_VARIABLE_JOKER_HIT, eez::IntegerValue(1));
      } else {
        eez::flow::setGlobalVariable(FLOW_GLOBAL_VARIABLE_JOKER_HIT, eez::IntegerValue(0));
      }
    }
// UI-Flags freigeben
    eez::flow::setGlobalVariable(FLOW_GLOBAL_VARIABLE_SPIN_IN_PROGRESS,
                                 eez::IntegerValue(0));
    eez::flow::setGlobalVariable(FLOW_GLOBAL_VARIABLE_CAN_START_SPIN,
                                 eez::IntegerValue(1));

    // Treffer in Globals
    eez::flow::setGlobalVariable(FLOW_GLOBAL_VARIABLE_HIT_GROUP,
                                 eez::IntegerValue(grp));

    // Trigger++ (für Flow)
    int err = 0;
    int32_t oldTrig =
        eez::flow::getGlobalVariable(FLOW_GLOBAL_VARIABLE_HIT_TRIGGER).toInt32(&err);
    if (err) oldTrig = 0;
    eez::flow::setGlobalVariable(FLOW_GLOBAL_VARIABLE_HIT_TRIGGER,
                                 eez::IntegerValue(oldTrig + 1));

    USBSerial.printf("HIT-Gruppe gesetzt: %d\n", grp);
    return;
  }

  // Nur nötig, falls du später wirklich SPIN_DONE/READY senden willst
  if (line.equalsIgnoreCase("SPIN_READY") || line.equalsIgnoreCase("SPIN_DONE")) {
    eez::flow::setGlobalVariable(FLOW_GLOBAL_VARIABLE_CAN_START_SPIN,
                                 eez::IntegerValue(1));
    eez::flow::setGlobalVariable(FLOW_GLOBAL_VARIABLE_SPIN_IN_PROGRESS,
                                 eez::IntegerValue(0));
    return;
  }

  // weitere Meldungen bei Bedarf auswerten
}


// === setup / loop ============================================================
void setup() {
  USBSerial.begin(115200);
  uint32_t waitStart = millis();
#if USE_NATIVE_USB
  while (!USBSerial && millis() - waitStart < 2000) {
    delay(10);
  }
#endif
  delay(300);
  USBSerial.println("PitterOmat ESP32-S3 + EEZ + RS485 (single buffer, no TCA BL) boot");
  settings_init();

  // Touch I2C0 (GT911)
  Wire.begin(15, 7);
  GT911.setPins(-1, 16);
  if (!GT911.begin(Wire, GT911_SLAVE_ADDRESS_L, 15, 7)) {
    USBSerial.println("GT911 not found");
  } else {
    GT911.setMaxTouchPoint(1);
  }

  // Display
  gfx->begin();
  init_lvgl();

  // EEZ / UI
  ui_init();
  eez::flow::setGlobalVariable(FLOW_GLOBAL_VARIABLE_DISPLAY_ID, eez::IntegerValue(DISPLAY_ID));
  settings_apply_to_flow();

  // RS485
  pinMode(RS485_DE_PIN, OUTPUT);
  digitalWrite(RS485_DE_PIN, LOW);
  RS485.begin(RS485_BAUD, SERIAL_8N1, RS485_RX_PIN, RS485_TX_PIN);
  sendAllSettingsToArduino();
  updateCachedStatesFromSettings();
}

void loop() {
  lv_timer_handler();
  eez_flow_tick();
  ui_tick();
  rs485Poll();
  usbPoll();
  pollFlowStateChanges();
  settings_process();
  delay(5);
}

